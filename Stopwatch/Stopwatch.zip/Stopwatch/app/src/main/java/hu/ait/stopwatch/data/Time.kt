package hu.ait.stopwatch.data

class Time (var time: String){
}